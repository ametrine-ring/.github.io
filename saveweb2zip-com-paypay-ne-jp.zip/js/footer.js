(function(){
  // SPのみアコーディオン
  $('.c-sitemap__heading').on('click', function() {
    $(this).next().slideToggle(300);
    $(this).toggleClass('active');
  });
  // アコーディオン状態監視
  $(window).on('resize', function() {
    if ( $('.c-sitemap__heading').css('pointer-events') == 'none' ) {
      $('.c-sitemap__list').attr('style', '');
      $('.c-sitemap__heading').removeClass('active');
    }
  });

  // sticky分の高さ調整
  (function () {
    // appDownload
    var $sticky = $(".stickyApp");
    var $closeSticky = $(".stickyApp__close");
    var $footer = $(".c-footer");

    if ($sticky.css("display") == "block") {
      $footer.addClass("c-footer--sticky");
    }

    $closeSticky.click(function(e){
      $footer.removeClass("c-footer--sticky");
    });

    // ロード後に画面幅が可変したとき固定要素の位置調整(スティッキーの状態変化を監視)
    // ※common.js上で既にページロード時のスティッキー(非)表示処理完了済み、それ以降の状態のみを監視
    var observer;
    var $target = $('.stickyApp');
    if (!$target.length) return;
    observer = new MutationObserver(function (records) {
      var targetState = $target.is(':visible');
      if (targetState) {
        if (!$footer.hasClass('c-footer--sticky')) $footer.addClass('c-footer--sticky');
      } else {
        $footer.removeClass('c-footer--sticky');
      }
    });

    observer.observe($target[0], {
      attributes: true,
      attributeFilter: ['style']
    });
  }());
})();