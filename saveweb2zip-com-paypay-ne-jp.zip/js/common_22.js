$(function() {

  // anchorLink
  var gl_scroll_speed = 600;
  var gl_fade_speed = 400;

  $('a[href^="#"]').on('click',function(e) {
    var href = $(this).attr('href');
    var target = $(href == '#' || href == '' ? 'html' : href);
    smoothScroll(0,target);
    target.attr('tabindex', '-1');
    target.focus();
    e.preventDefault();
  });

  // ヘッダー下スクロール時に隠す
  (function() {
    var $header
    var startPos = 0;

    // /store-online/は除外
    if (location.href.match(/store-online/)) return;

    // /store/cashless//lp-02/と/store/offer/direct-lp-02/以外の場合
    if (location.href.match('/store/(?!cashless/lp-02/)(?!offer/direct-lp-02/)')) return;

    // 固定ヘッダーがない
    if (location.search.match(/appwebview/)) return;

    var $header = getHeaderElement();
    if (!$header.length) return;

    $(window).on('load scroll', function(e) {
      var currentPos = $(this).scrollTop();
      var headerHeight = $header.outerHeight();

      // メニューが開いている場合は除外
      if (!$('body').hasClass('isHeaderMenuActive')) {
        // ヘッダーの高さよりスクロール済みで、かつさらに下にスクロール
        // ページ遷移時
        if ('load' === e.type) {
          if (currentPos > headerHeight) slideUp();
          else slideDown();

        // スクロール時
        } else if ('scroll' === e.type) {
          // 下スクロール
          if (currentPos > headerHeight && currentPos > startPos) {
            slideUp();
          }
          // 上スクロール
          else if (currentPos < startPos) {
            slideDown();
          }
        }
      }

      startPos = currentPos;

      // ヘッダースライドして隠れる
      function slideUp() {
        $header.css('top', '-' + headerHeight + 'px');
        $(".c-header__search-box, .c-header__search-link").removeClass("is-active");
      }
      // ヘッダースライドして現れる
      function slideDown() {
        $header.css('top', '0');
      }
    });

    // 固定ヘッダー取得
    function getHeaderElement() {
      var $header;
      $header = $('.header--lp');
      if (!$header.length) $header = $('.header');
      if (!$header.length) $header = $('.headerVer2');
      if (!$header.length) $header = $('.c-header');
      return $header;
    }
  }());

  // ヘッダー後続要素の位置調整
  (function () {
    var observer;
    var $header;
    var showClassName = 'header--show';

    // 固定ヘッダーがない
    if (location.search.match(/appwebview/)) return;


    $header = getHeaderElement();
    if (!$header.length) return;

    observer = new MutationObserver(function (records) {
      var targetState = $header.is(':visible');
      if (targetState) {
        if (!$header.hasClass(showClassName)) $header.addClass(showClassName);
        unAddedStyles = false;
      } else {
        if ($header.hasClass(showClassName)) $header.removeClass(showClassName);
      }
    });

    observer.observe($header[0], {
      attributes: true,
      attributeFilter: ['style']
    });

    // 固定ヘッダー取得
    function getHeaderElement() {
      var $header;
      $header = $('.header--lp');
      if (!$header.length) $header = $('.header');
      if (!$header.length) $header = $('.headerVer2');
      if (!$header.length) $header = $('.c-header');
      return $header;
    }
  }());

  // 検索結果ページのページネーション後、位置調整
  (function () {
    var observer;
    var $target = $('#searchResult');

    // 固定ヘッダーがない
    if (location.search.match(/appwebview/)) return;
    if (!$('.header--lp').length && !$('.header').length && !$('.headerVer2').length) return;
    // 検索結果がない
    if (!$target.length) return;

    observer = new MutationObserver(function (records) {
      // リスト追加更新時のみ対象
      $.each(records, function (i, v) {
        if ('childList' === records[i].type && records[i].addedNodes.length) {
          addEvent();
        }
      });
    });

    observer.observe($target[0], {
      childList: true,
      subtree: true
    });

    function addEvent() {
      var $context = $('.mt-site-search-pagination-item__link');
      if (!$target.length) return;
      $context.off('click.position.pagenation');
      $context.on('click.position.pagenation', function (e) {
        setTimeout((function() {
          window.scroll(0, calcPosition());
        }).bind(this, e), 100);
      });
    }

    function calcPosition() {
      var headerGap = 0;
      if ($('.header--lp').length) headerGap += $target.offset().top - $('.header--lp').outerHeight();
      else if ($('.header').length) headerGap += $target.offset().top - $('.header').outerHeight();
      else if ($('.headerVer2').length) headerGap += $target.offset().top - $('.headerVer2').outerHeight();
      return headerGap;
    }
  }()); // 検索結果ページのページネーション後、位置調整ここまで

  // smoothScroll
  var smoothScroll = function(offset,target) {
    if (target.length) {
      var targetPos = target.offset().top - offset - calcheaderGap(target.prop("tagName").toLowerCase());
      $('body,html').animate({scrollTop: targetPos}, gl_scroll_speed);
    }

    function calcheaderGap(tagName) {
      var headerGap = 0;
      var targetPos;
      var currentPos;

      if (location.search.match(/appwebview/)) return headerGap; // 0

      if ('html' === tagName) return headerGap; // 0

      targetPos = target.offset().top - offset;
      currentPos = $(window).scrollTop() - offset;

      // ヘッダー表示状態（スライドダウン）のときは
      // ヘッダー高さ分のスクロールを確保
      if (currentPos > targetPos) {
        if ($('.header--lp').length) headerGap += $('.header--lp').outerHeight();
        else if ($('.header').length) headerGap += $('.header').outerHeight();
        else if ($('.headerVer2').length) headerGap += $('.headerVer2').outerHeight();
        else if ($('.c-header').length) headerGap += $('.c-header').outerHeight();
      }

      return headerGap;
    }
  }

  // pagetop
  var $top = $(".top");
  $top.hide();
  $(window).on("scroll", function() {
    if ($(this).scrollTop() > 100) {
      $top.fadeIn(300);
    } else {
      $top.fadeOut(300);
    }
  });

  // 旧 parameterDecision
  if(location.search.match(/appwebview/)) {
    $(".app-none-display").hide();
    $(".app-show-display").show();
  } else {
    $(".app-erase-display").show();
    $(".app-show-display").hide();
  }

  // appwebview parameterDecision
  if(location.search.match(/appwebview/)) {
    $(".appView--hide").hide();
    $(".appView--show").show();
  } else {
    $(".appView--hide").show();
    $(".appView--show").hide();
  }

  // 旧 userAgentDecision
  var ua = navigator.userAgent;
  if(ua.search(/iPhone/) !== -1 || ua.search(/iPad/) !== -1) {
    $(".ua-device-ios").show();
    $(".ua-device-ios-only").show();
  } else if(ua.search(/Android/) !== -1) {
    $(".ua-device-android").show();
    $(".ua-device-android-only").show();
  } else {
    $(".ua-device-ios").show();
    $(".ua-device-android").show();
  }

  // userAgentDecision
  var ua = navigator.userAgent;
  if(ua.search(/iPhone/) !== -1 || ua.search(/iPad/) !== -1) {
    $(".userDevice--ios").show();
    $(".userDevice--iosOnly").show();
  } else if(ua.search(/Android/) !== -1) {
    $(".userDevice--android").show();
    $(".userDevice--androidOnly").show();
  } else {
    $(".userDevice--ios").show();
    $(".userDevice--android").show();
    userDeviceOtherDisplayPC(); // userDevice--otherDisplayPc
  }

  function userDeviceOtherDisplayPC() {
    var mediaQuery = matchMedia('(max-width: 750px)');
    handleMediaQuery(mediaQuery);
    mediaQuery.addListener(handleMediaQuery);

    function handleMediaQuery(mq) {
      if (!$(".userDevice--otherDisplayPc").length) return;
      if(location.search.match(/appwebview/)) return;
      if (mq.matches) {
        $(".userDevice--otherDisplayPc").hide();
      } else {
        $(".userDevice--otherDisplayPc").show();
      }
    }
  }

  // sticky appDownload
  var $body = $("body");
  var $sticky = $(".stickyApp");
  var $closeSticky = $(".stickyApp__close");
  var $top = $(".top");
  var $footer = $(".footerVer2");

  if ($sticky.css("display") == "block") {
    $body.addClass("page--appSticky");
    $footer.addClass("footerVer2--sticky");
    $top.addClass("top--sticky");
  }

  $closeSticky.click(function(e){
    $sticky.remove();
    $body.removeClass("page--appSticky");
    $footer.removeClass("footerVer2--sticky");
    $top.removeClass("top--sticky");
  });

  // globalTransitionがある場合の後続要素の位置調整
  var $globalTransition = $(".globalTransition");
  if($globalTransition.length && $globalTransition.css("display") == "block"){
    $(".headerVer2").addClass("globalTransition--show");
  }

  // ロード後に画面幅が可変したとき固定要素の位置調整(スティッキーの状態変化を監視)
  // ※common.js上で既にページロード時のスティッキー(非)表示処理完了済み、それ以降の状態のみを監視
  (function () {
    var observer;
    var $target = $('.stickyApp');
    var $footer = $('.footer');
    var $footerVer2 = $('.footerVer2');
    var $top = $('.top');

    if (!$target.length) return;
    observer = new MutationObserver(function (records) {
      var targetState = $target.is(':visible');
      if (targetState) {
        if (!$footer.hasClass('footer--sticky')) $footer.addClass('footer--sticky');
        if (!$footerVer2.hasClass('footerVer2--sticky')) $footerVer2.addClass('footerVer2--sticky');
        if (!$top.hasClass('top--sticky')) $top.addClass('top--sticky');
      } else {
        $footer.removeClass('footer--sticky');
        $footerVer2.removeClass('footerVer2--sticky');
        $top.removeClass('top--sticky');
      }
    });

    observer.observe($target[0], {
      attributes: true,
      attributeFilter: ['style']
    });
  }());

  // OneTrust Cookie バナーが表示されたときに、言語切替ボタン, ページトップへ戻るボタン, チャットボットボタンの位置を変更する。
  // バナー表示中は <head> に id付き <style> を追加し、バナーが非表示になれば <style> を削除
  (function () {
    var observer;
    var $body = $("body");
    removeBannerFlag = false;

    observer = new MutationObserver(function (mutations) {
      Array.prototype.forEach.call(mutations, function (mutation) {
        Array.prototype.forEach.call(mutation.addedNodes, function (node) {
          if (!isNode(node)) { return false }
          if (!node.querySelector('#onetrust-banner-sdk')) { return false }

          _generateStyleElement()
          $(window).on('resize', function () {
            _generateStyleElement()
          })

          function _generateStyleElement() {
            var windowHeight = $(window).height();
            var bannerHeight = $(node).find('#onetrust-banner-sdk').outerHeight()
            var pageTopButtonHeight = 50;
            var style = '';
            style += '<style id="cookieBannerStyle">';
            style += '@media screen and (min-width: 751px) {'
            style += '#wovn-translate-widget, .page--appSticky #wovn-translate-widget { bottom: ' + (bannerHeight + 16) + 'px !important; }'
            style += '}'
          	style += '#wovn-translate-widget, .page--appSticky #wovn-translate-widget { bottom: ' + (bannerHeight + 16) + 'px !important; }'
            style += 'body #wovn-translate-widget.mobile.wovn--slide-in { bottom: ' + (bannerHeight + 16) + 'px !important; }'
            style += 'body #wovn-translate-widget.mobile.wovn--slide-out { bottom: ' + (bannerHeight + 8) + 'px !important; }'
            style += '.chatbotFrame--sticky {transform: none !important;}'
            style += '#va-window { z-index: 2147483646 !important; }'

            // ブラウザの高さ 640px以下 チャットボットボタンを画面上の要素とかぶらないよう、非表示にする
            if(windowHeight >= 640){
              style += '#va-container.va-theme-overlay #va-launcher, #va-container.va-theme-toast #va-launcher{ bottom: ' + (bannerHeight + pageTopButtonHeight + 16 * 3) + 'px !important; }'
              style += '.chatbotFrame--sticky { bottom: ' + bannerHeight + 'px !important; right: '+ ( 16 * 2 + pageTopButtonHeight) +'px !important;}'
              style += '.chatbotFrame--side { bottom: ' + (bannerHeight + pageTopButtonHeight + 16 * 2) + 'px !important; }'
              style += '.top{ bottom: ' + (bannerHeight + 16 + 8) + 'px; }'
            }else{
              style += '#va-container.va-theme-overlay #va-launcher, #va-container.va-theme-toast #va-launcher{ bottom: ' + (bannerHeight + 16) + 'px !important; }'
              style += '.chatbotFrame--sticky { display: none !important; }'
              style += '.chatbotFrame--side { display: none !important; }'
              style += '.top{ bottom: ' + (bannerHeight + 16) + 'px; }'
              style += '@media screen and (min-width: 751px) {'
              style += '.chatbotFrame--sticky { right: '+ ( 16 * 2 + pageTopButtonHeight) +'px !important;}'
              style += '}'
              style += '@media screen and (orientation: portrait){'
              style += '.top{ bottom: ' + (bannerHeight + 16) + 'px; }'
              style += '}'
              style += '@media screen and (orientation: landscape) and (max-width: 750px) {'
              style += '#va-container.va-theme-overlay #va-launcher, #va-container.va-theme-toast #va-launcher{ bottom: 16px !important; }'
              style += '}'
            }

            style += '</style>';

            if( removeBannerFlag ){ return false }
            if ($('#cookieBannerStyle').length) {
              $('#cookieBannerStyle').remove();
              $('head').append(style);
            } else {
              $('head').append(style);
            }
          }

          observer.disconnect();
        });
      });
    });

    observer.observe($body[0], {
      childList: true,
      attributes: false,
      characterData: false,
      subtree: false
    });
    function isNode(obj) {
      return obj && obj.nodeType && obj.nodeType === 1;
    }
    $(document).on('click', '#onetrust-accept-btn-handler', function () {
      $('#cookieBannerStyle').remove()
      removeBannerFlag = true;
    }).on('click', '.ot-pc-refuse-all-handler', function () {
      $('#cookieBannerStyle').remove()
      removeBannerFlag = true;
    }).on('click', '.onetrust-close-btn-handler', function () {
      $('#cookieBannerStyle').remove()
      removeBannerFlag = true;
    })

  }());
});
