$(function() {
  // ?appwebviewの引継ぎ
  // help、help-merchant、help-businessaccountは不要なので読み込まない
  if(!$('.contents .jsEntryBtn').length){
    var paypay = "paypay.ne.jp/";
    var aboutpaypay = "about.paypay.ne.jp/";
    if(location.search.match(/appwebview/)) {
      var param = 'appwebview';
      linkParameter();
    }
    if(location.search.match(/softbank/)) {
      var param = 'softbank';
      linkParameter();
    }
    if(location.search.match(/ymobile/)) {
      var param = 'ymobile';
      linkParameter();
    }
    if(location.search.match(/yj/)) {
      var param = 'yj';
      linkParameter();
    }
  }
  function linkParameter() {
    // フッターの「このページをシェア」などのシェアボタンを除く
    $('a').not('.footerShare a, .footerShareVer2 a, .share a, .c-footerShare a').each(function(){
      var link = $(this).attr('href');
      if(!link){return}
      if((link.indexOf(paypay) !== -1 || link.indexOf(aboutpaypay) !== -1 || link.match(/^\//)) && link.indexOf(param) == -1) {
        if(link.indexOf('#') !== -1) {
          var index = link.indexOf('#');
          var permalink = link.substring(0, index);
          var anchor = link.substring(index);
          if (link.indexOf('?') !== -1) {
            $(this).attr('href', permalink + '&' + param + anchor);
          } else {
            $(this).attr('href', permalink + '?' + param + anchor);
          }
        } else {
          if(link.indexOf('?') !== -1) {
            $(this).attr('href', link + '&' + param);
          } else {
            $(this).attr('href', link + '?' + param);
          }
        }
      }
    });
  }
});
