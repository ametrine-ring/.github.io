;(function($){
  // accordion
  $.extend({
    toggleAccordion : function(){
      var $acorBox = $('.js-AcorBox');
      var $acorBtn = $('.js-AcorBtn');
      $acorBox.not('.is-AcorShow').find('.js-AcorDetail').css('display','none');
      $acorBtn.click(function(e){
        var $this = $(this);
        var acorBox = $acorBox.has($this);
        var acorDetail = acorBox.find('.js-AcorDetail');
        if(!(acorDetail.is(':animated'))){
          if(!(acorBox.hasClass('is-AcorShow'))){
            acorBox.removeClass('is-AcorHide').addClass('is-AcorShow');
            acorDetail.slideDown(300,function(){
            });
          } else {
            acorDetail.slideUp(300,function(){
              acorBox.removeClass('is-AcorShow').addClass('is-AcorHide');
            });
          }
        }
      });
    }
  });

  // flowPosition (jQueryプラグイン)
  // フローの現在地を表示する
  $.fn['flowPosition'] = function() {
    // 設定（フロー共通）
    var flowButtonCurrentClass = 'position__item--current'; // 現在のフロークラス名
    var tpl = { // テンプレート
      flow: '<ol class="flow__position position">',
      flowButton: '<li class="position__item"><span class="position__dot">'
    };

    /**
     * DOM要素を設定する
     * @param {Object} $el 設定されたDOM要素
     */
    var setElements = function ($el) {
        $el.$sliderList = $el.$slider.find('.flow__list'); // フロースライダーエリア要素
        $el.$sliderItems = $el.$slider.find('.flow__item'); // フローアイテム要素
    };

    /**
     * 各情報を設定する
     * @param {Object} $el 設定されたDOM要素
     * @param {Object} settings 設定された情報
     */
    var setFlowWidth = function ($el, settings) {
      settings.sliderWidth = Math.ceil($el.$slider.outerWidth()); // フロースライダーの内包幅
      settings.threshold = settings.sliderWidth / 2; // 現在のフローを特定する閾値
    };

    /**
     * フローアイテムの位置情報を設定する
     * @param {Object} $el 設定されたDOM要素
     * @param {Object} settings 設定された情報
     */
    var setCurrentPositionMapping = function ($el, settings) {
      var slideItemsMapping = settings.slideItemsMapping = [];
      var sliderItemsPos = 0;

      $el.$sliderItems.each(function(i, v) {
        sliderItemsPos += Math.floor($(this).outerWidth(true));
        slideItemsMapping.push(sliderItemsPos);
      });
    };

    /**
     * 現在位置要素を表示する
     * @param {Object} $el 設定されたDOM要素
     * @param {Object} tpl 現在位置要素のテンプレート
     */
    var addCurrentPositionElement = function ($el, tpl) {
      var flowButtons = '';
      for (var i = 0, l = $el.$sliderItems.length; i < l; i++) flowButtons += tpl.flowButton;
      $(tpl.flow).append(flowButtons).appendTo($el.$slider);
      $el.$flowButtons = $el.$slider.find('.position__item');
    };

    /**
     * 現在位置表示を更新する
     * @param {jQueryObject} $target
     */
    var updateCurrentPositionDisplay = function ($target) {
      $target.siblings().removeClass(flowButtonCurrentClass);
      $target.addClass(flowButtonCurrentClass)
    };

    /**
     * 横スクロール監視
     * @param {Object} $el 設定されたDOM要素
     * @param {Object} settings 設定された情報
     */
    var attachScrollEvent = function ($el, settings) {
      $el.$sliderList.on('scroll', function(e) {
        var threshold = settings.threshold;
        var slideItemsMapping = settings.slideItemsMapping;
        var sliderWidth = settings.sliderWidth;
        var scrollPos = Math.ceil($(this).scrollLeft());
        var index;

          // 現在のフロー判定
        for (var i = 0, l = slideItemsMapping.length; i < l; i++) {
          // 先頭
          if (0 === scrollPos) {
            index = 0;
            break;
          // 末尾
          } else if (slideItemsMapping[slideItemsMapping.length - 1] <= scrollPos + sliderWidth) {
            index = slideItemsMapping.length - 1;
            break;
          // それ以外
          } else if (slideItemsMapping[i] > scrollPos + threshold) {
            index = i;
            break;
          }
        }
        // 現在位置表示を更新する
        updateCurrentPositionDisplay($el.$flowButtons.eq(index));
      }).trigger('scroll');
    };

    /**
     * フロー要素幅監視
     * @param {Object} $el 設定されたDOM要素
     * @param {Object} settings 設定情報
     */
    var attachResizeEvent = function ($el, settings) {
      $(window).on('resize', function(e) {
        // フロー要素幅を設定する
        setFlowWidth($el, settings);
        // フローアイテムの位置情報を設定する
        setCurrentPositionMapping($el, settings);
        // 現在の位置を更新
        $el.$sliderList.trigger('scroll');
      });
    }

    /**
     * 実行処理
     */
    return $(this).each(function(i, v) {
      // 設定（フロー個別）
      var settings = {
        slideItemsMapping: [], // 各フローの開始位置
        sliderWidth: 0, // フロースライダーの内包する幅
        threshold: 0 // 閾値（現在のフローを特定するためのフロースライダー表示幅の左からの距離）
      };

      var $el = {
        $slider: $(this).find('.flow__detail'), // プラグイン起点要素
        $sliderList: null, // フロースライダーエリア要素
        $sliderItems: null, // フローアイテム要素
        $flowButtons: null // フローの現在地表示要素
      };

      // DOM要素を設定する
      setElements($el);

      // フロー要素幅を設定する
      setFlowWidth($el, settings);

      // フローアイテムの位置情報を設定する
      setCurrentPositionMapping($el, settings);

      // 現在位置要素を表示する
      addCurrentPositionElement($el, tpl);

      // 横スクロール監視
      attachScrollEvent($el, settings);

      // フロー要素幅監視
      attachResizeEvent($el, settings);
    });
  };

  $(function(){
    // lazyload
    $(".lazyload").lazyload({
      effect: "fadeIn"
    });

    // accordion
    $.toggleAccordion();

    // flowPosition起動
    $('.flow').flowPosition();

    // bannerModal
    var $modalWrap = $('.js-modal');
    var $modalClose = $('.js-modalClose');
    setTimeout(function(){
      eventModalContents();
    }, 500);
    function eventModalContents(){
      if($.cookie('modalCloseFlag') != 'on') {
        $modalWrap.addClass('is-modalContentsShow');
      }
      if($modalWrap.hasClass('is-modalContentsShow')){
        $('html, body').css('overflow', 'hidden');
      }
      $modalClose.click(function(){
        modalContentsClose();
      });
      $(document).on('click.modalContents',function(e){
        if($(e.target).hasClass('js-modal')){
          modalContentsClose();
        }
      });
    }

    function modalContentsClose(){
      $modalWrap.removeClass('is-modalContentsShow');
      $(document).off('click.modalContents');
      $('html, body').css('overflow', 'auto');
      $.cookie('modalCloseFlag', 'on', { expires: 1,path: '/' }); //cookieの保存
    }

    // carousel
    function carouselSetting(){
      var width = $(window).width();
      if(width <= 750){
        $('.js-carousel').not('.slick-initialized').slick({
          infinite: false,
          centerMode: true,
          centerPadding: '16vw', //60px
          arrows: false,
          dots: true,
          dotsClass: 'carousel__dots'
        });
      } else {
        $('.js-carousel.slick-initialized').slick('unslick');
      }
    }
    carouselSetting();
    $(window).resize(function() {
      carouselSetting();
    });

    // modalSlider
    var $modalSlider = $('.js-modalSlider');
    var $modalSliderOpen = $('.js-modalSliderOpen');
    var $modalSliderClose = $('.js-modalSliderClose');
    // slick.jsの設定
    function modalSliderSetting(){
      $('.js-modalSliderContents').slick({
        fade: true,
        prevArrow: '<button type="button" class="modalContents__button--prev">前へ</button>',
        nextArrow: '<button type="button" class="modalContents__button--next">次へ</button>',
        responsive: [
          {
            breakpoint: 750,
            settings: {
              arrows: false,
              dots: true,
              dotsClass: 'modalContents__dots'
            }
          }
        ]
      });
    }
    $modalSliderOpen.click(function(){
      if($modalSlider.hasClass('is-modalContentsShow')){
        modalContentsClose();
      } else {
        $modalSlider.addClass('is-modalContentsShow');
        $('html, body').css('overflow', 'hidden');
        $('.js-modalSlider').show(); //モーダル表示
        $modalSliderClose.click(function(){
          modalSliderClose();
        });
        $(document).on('click.modalSliderContents',function(e){
          if($(e.target).hasClass('js-modalSlider')){
            modalSliderClose();
          }
        });
        var index = $(this).index(); //クリックされた画像番号
        modalSliderSetting();
        $('.js-modalSliderContents').slick('slickGoTo', index);//メイン画像の切替
      }
    });
    function modalSliderClose(){
      $modalSlider.removeClass('is-modalContentsShow');
      $('.js-modalSlider').hide();
      $(document).off('click.modalSliderContents');
      $('html, body').css('overflow', 'auto');
      $('.js-modalSliderContents.slick-initialized').slick('unslick');
    }

    // アニメーション
    var $animationScale = $('.animation--scale');
    var $animationFadein = $('.animation--fadein');
    $animationScale.addClass('is-hide');
    $animationFadein.children().addClass('animationTarget--fadein');
    // IEの場合、classを付与
    var userAgent = window.navigator.userAgent.toLowerCase();
    if(userAgent.indexOf('msie') != -1 || userAgent.indexOf('trident') != -1 || '' ){
      $animationScale.children().addClass('device--ie');
      $animationFadein.children().addClass('device--ie');
      $('.animationTarget--float').addClass('device--ie');
    }
    $(window).scroll(function(){
      $animationScale.each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if(scroll > imgPos - windowHeight + windowHeight / 4){
          $(this).removeClass('is-hide').addClass('is-show');
          $(this).children().addClass('animationTarget--scale');
        }
      });
      $animationFadein.each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if(scroll > imgPos - windowHeight + 200){
          $(this).children().addClass('is-show');
        }
      });
    });

    // Pop Up
    var $popup = $('.popup');
    var $popupClose = $popup.find('.popup__close');
    var ua = navigator.userAgent;
    // ポップアップ無し
    if(!$popup.length || !$popupClose.length) return;
    // PCのみ
    if(ua.search(/iPhone/) !== -1 || ua.search(/iPad/) !== -1 || ua.search(/Android/) !== -1) return;
    $popup.show();
    $popupClose.on('click', function(e){
      e.preventDefault();
      $popup.fadeOut(300);
    });
  });
})(jQuery);

$(function(){
  // stickyApp表示開始調整
  var $body = $("body");
  var $top = $(".top");
  var $footer = $(".c-footer");
  var $sticky = $(".stickyApp__body");
  $sticky.css('display', 'none');
  $body.removeClass("page--appSticky");
  $footer.removeClass("c-footer--sticky");
  $top.removeClass("top--sticky");

  $(window).on("scroll", function() {
    if (($('.stickyApp').length) && (location.search.match(/appwebview/) == null)) {
      if ($(this).scrollTop() > 100) {
        $sticky.fadeIn();
        $body.addClass("page--appSticky");
        $footer.addClass("c-footer--sticky");
        $top.addClass("top--sticky");
      } else {
        $sticky.hide();
        $body.removeClass("page--appSticky");
        $footer.removeClass("c-footer--sticky");
        $top.removeClass("top--sticky");
      }
    }
  });
});