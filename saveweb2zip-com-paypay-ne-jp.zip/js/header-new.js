$(window).bind("unload",function(){});

$(function () {
  // ハンバーガーメニュー開閉
  $(".c-header__open").on("click", function () {
    if ($(this).hasClass("active") && $(".c-submenu").hasClass("show")) {
      $(".c-submenu").removeClass("show");
    }
    $(this).toggleClass("active");
    $(".c-header__menu").toggleClass("show");

    if ($(".c-header__menu").hasClass("show")) {
      $(".has-submenu").on("click", function () {
        $(this).next(".c-submenu").addClass("show");
      });

      $(".c-submenu__back").on("click", function () {
        $(".c-submenu").removeClass("show");
      });
      bgFixedOn();
    } else {
      $(".c-submenu").removeClass("show");
      bgFixedOff();
    }
  });

  let scrollTop;

  function bgFixedOn() {
    scrollTop = $(window).scrollTop();

    $("body").css({
      position: "fixed",
      top: -scrollTop,
      left: 0,
      right: 0,
      bottom: 0,
    });
  }

  function bgFixedOff() {
    $("body").css({
      position: "",
      top: "",
      left: "",
      right: "",
      bottom: "",
    });

    window.scroll({
      top: scrollTop,
      behavior: "instant",
    });
  }

  // ヘッダー下スクロール時に隠す
  (function() {
    var $header
    var startPos = 0;

    // 固定ヘッダーがない
    if (location.search.match(/appwebview/)) return;

    var $header = getHeaderElement();
    if (!$header.length) return;

    $(window).on('load scroll resize', function(e) {
      var currentPos = $(this).scrollTop();
      var headerHeight = $header.outerHeight();

      // ヘッダーの高さよりスクロール済みで、かつさらに下にスクロール
      // ページ遷移時
      if ('load' === e.type) {
        if (currentPos > headerHeight) slideUp();
        else slideDown();

      // スクロール時
      } else if ('scroll' === e.type) {
        // 下スクロール
        if (currentPos > headerHeight && currentPos > startPos) {
          slideUp();
        }
        // 上スクロール
        else if (currentPos < startPos) {
          slideDown();
        }
      }

      // パンくずが表示されている時シャドウ非表示
      var $breadcrumb = $('.c-breadcrumb');
      var breadcrumbHeight = $breadcrumb.height();
      var shadowClassName = 'c-header--noShadow';
      if (currentPos < breadcrumbHeight) {
        if (!$header.hasClass(shadowClassName)) $header.addClass(shadowClassName);
      } else {
        if ($header.hasClass(shadowClassName)) $header.removeClass(shadowClassName);
      }

      startPos = currentPos;

      // ヘッダースライドして隠れる
      function slideUp() {
        $header.css('top', '-' + headerHeight + 'px');
        $(".c-header__search-box, .c-header__search-link").removeClass("is-active");
      }
      // ヘッダースライドして現れる
      function slideDown() {
        $header.css('top', '0');
      }
    });
  }());

  // ヘッダー後続要素の位置調整
  (function () {
    var observer;
    var $header;
    var showClassName = 'header--show';

    // 固定ヘッダーがない
    if (location.search.match(/appwebview/)) return;

    $header = getHeaderElement();
    if (!$header.length) return;

    observer = new MutationObserver(function (records) {
      var targetState = $header.is(':visible');
      if (targetState) {
        if (!$header.hasClass(showClassName)) $header.addClass(showClassName);
        unAddedStyles = false;
      } else {
        if ($header.hasClass(showClassName)) $header.removeClass(showClassName);
      }
    });

    observer.observe($header[0], {
      attributes: true,
      attributeFilter: ['style']
    });
  }());

  // 固定ヘッダー取得
  function getHeaderElement() {
    var $header = $('.c-header');
    return $header;
  }

  // 検索窓開閉
  $(".c-header__search-link").on('click', function () {
    $(this).toggleClass('is-active');
    $(".c-header__search-box").toggleClass("is-active");
  });
});
